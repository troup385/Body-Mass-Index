﻿/*Author: Joshua Troup
  Purpose: Calculate a person's body mass index using the program and using the chart
  to determine if the user is healthy
  */


using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Troup_BMI
{
    public partial class BMIForm : Form
    {
        public BMIForm()
        {
            InitializeComponent();
        }

        private void calculateButton_Click(object sender, EventArgs e)
        {
            double weight;      // To hold weight of user
            double height;     // To hold height of user
            double bmi;       // To hold BMI

            // Get the weight of user and assign it to
            // the weight variable.
            weight = double.Parse(weightTextBox.Text);

            // Get the height of user and assign it to
            // the height variable.
            height = double.Parse(heightTextBox.Text);

            // Calculate BMI.
            bmi = weight * 703 / (height * height);

            // Display the BMI in the bmiLabel control.
            bmiLabel.Text = bmi.ToString();
        }
    }
}
